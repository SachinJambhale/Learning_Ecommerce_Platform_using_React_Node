import * as React from "react";

interface IPaymentProps {}

const Payment: React.FunctionComponent<IPaymentProps> = (props) => {
  return (
    <>
      <h2>Payment Component</h2>
    </>
  );
};

export default Payment;
