import * as React from "react";

interface ICustomerProfileProps {}

const CustomerProfile: React.FunctionComponent<ICustomerProfileProps> = (
  props
) => {
  return (
    <>
      <h2>Customer Profile</h2>
    </>
  );
};

export default CustomerProfile;
