import * as React from "react";

interface ITCProps {}

const TC: React.FunctionComponent<ITCProps> = (props) => {
  return (
    <>
      <h2>Terms and conditions</h2>
    </>
  );
};

export default TC;
