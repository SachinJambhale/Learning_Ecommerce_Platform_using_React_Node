import * as React from "react";

interface IDashboardProps {}

const Dashboard: React.FunctionComponent<IDashboardProps> = (props) => {
  return (
    <>
      <h2>Dashboard Component</h2>
    </>
  );
};

export default Dashboard;
