import * as React from "react";

interface IOrderProps {}

const Order: React.FunctionComponent<IOrderProps> = (props) => {
  return (
    <>
      <h2>Order Component</h2>
    </>
  );
};

export default Order;
