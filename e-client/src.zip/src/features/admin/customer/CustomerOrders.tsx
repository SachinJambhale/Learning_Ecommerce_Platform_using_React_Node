import * as React from "react";

interface ICustomerOrdersProps {}

const CustomerOrders: React.FunctionComponent<ICustomerOrdersProps> = (
  props
) => {
  return (
    <>
      <h2>Customer Orders</h2>
    </>
  );
};

export default CustomerOrders;
